package com.ecommerce.service;

import com.ecommerce.model.DetalleOrden;

public interface IDetalleOrdenService {
	DetalleOrden save(DetalleOrden detalleOrden);

}
